# INTELLIGENT CAREER GUIDANCE SYSTEM

Youtube video link: https://www.youtube.com/watch?v=fMQfYWDIpWU
